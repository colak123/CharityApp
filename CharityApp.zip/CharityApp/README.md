# CharityApp
React, Tailwind &amp; Firebase charity app. 
