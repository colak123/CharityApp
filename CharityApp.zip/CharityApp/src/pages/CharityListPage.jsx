import CharityList from '../components/CharityList'

const CharityListPage = () => {
  return (
    <CharityList />
    )
}

export default CharityListPage