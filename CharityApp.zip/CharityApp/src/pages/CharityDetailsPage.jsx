import CharityDetails from "../components/CharityDetails";

const CharityDetailsPage = () => {
  return (

    <CharityDetails />
    
  );
};

export default CharityDetailsPage;
