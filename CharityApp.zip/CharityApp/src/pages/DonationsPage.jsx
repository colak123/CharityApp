import UserDonations from '../components/UserDonations'

const DonationsPage = () => {
  return (

    <UserDonations />
    )
}

export default DonationsPage