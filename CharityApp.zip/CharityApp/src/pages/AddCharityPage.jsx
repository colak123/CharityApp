import AddCharityForm from "../components/AddCharityForm"

const AddCharityPage = () => {
  return (
    <AddCharityForm />
  )
}

export default AddCharityPage